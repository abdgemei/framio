<?php 
$config['PhpThumb']['thumbs_path'] = 'content/thumbs';
