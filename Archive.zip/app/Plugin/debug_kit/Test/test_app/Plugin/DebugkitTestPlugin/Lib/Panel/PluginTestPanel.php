<?php

class PluginTestPanel extends DebugPanel {
}