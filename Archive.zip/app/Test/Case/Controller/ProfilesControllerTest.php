<?php
App::uses('ProfilesController', 'Controller');

/**
 * ProfilesController Test Case
 *
 */
class ProfilesControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.profile',
		'app.user',
		'app.group',
		'app.upload'
	);

}
