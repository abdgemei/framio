<?php
App::uses('AlbumsController', 'Controller');

/**
 * AlbumsController Test Case
 *
 */
class AlbumsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.album',
		'app.photo',
		'app.upload',
		'app.user',
		'app.group',
		'app.profile',
		'app.profile_picture',
		'app.photo_metadatum',
		'app.album_photo'
	);

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
	}

/**
 * testView method
 *
 * @return void
 */
	public function testView() {
	}

/**
 * testAdd method
 *
 * @return void
 */
	public function testAdd() {
	}

/**
 * testEdit method
 *
 * @return void
 */
	public function testEdit() {
	}

/**
 * testDelete method
 *
 * @return void
 */
	public function testDelete() {
	}

}
