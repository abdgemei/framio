<?php
App::uses('PagesController', 'Controller');

/**
 * PagesController Test Case
 *
 */
class PagesControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.page'
	);

/**
 * testDisplay method
 *
 * @return void
 */
	public function testDisplay() {
	}

}
